<?php

class AlbumDetailQueryReqPkt extends Data {
    public $albumID = 0;
}