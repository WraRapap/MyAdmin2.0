<?php
$ServiceType['0'] = 'Album';
$ServiceType['1'] = 'Join';
$ServiceType['2'] = 'Account';
$ServiceType['700'] = 'Activity';
