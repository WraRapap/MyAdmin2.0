<?php

class LoginRespPkt {
    public $UserData;
}