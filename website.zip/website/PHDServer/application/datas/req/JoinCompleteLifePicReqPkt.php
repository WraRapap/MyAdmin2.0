<?php

class JoinCompleteLifePicReqPkt extends Data {
    public $memberID = 0;
    public $index = 0;
}