<?php

class JoinNormalGetReqPkt extends Data {
     public $id = 0;
}