<?php

class ActivityModRespPkt {
}