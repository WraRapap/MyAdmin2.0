<?php

class ActivityImgAddReqPkt extends Data {
    public $id = 0;
    public $monthly_id;
    public $name;
    public $is_cover;
}