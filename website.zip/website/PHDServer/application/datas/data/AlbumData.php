<?php

class AlbumData extends Data
{
    public $id;
    public $name;
    public $type;
}