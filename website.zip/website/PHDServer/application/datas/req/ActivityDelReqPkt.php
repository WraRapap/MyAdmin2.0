<?php

class ActivityDelReqPkt extends Data {
    public $id = 0;
}