<?php

class ReqInfoPkt extends Data {
    public $ST = -1;
    public $AT = -1;
    public $data = null;
}