<?php

class AlbumPic extends Data
{
    public $album_id;
    public $path;
}