<?php

class ActivityQueryByIDRespPkt {
    public $MonthlyData = null;            //帳號資料
}