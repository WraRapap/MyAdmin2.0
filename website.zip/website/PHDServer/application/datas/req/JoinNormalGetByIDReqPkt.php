<?php

class JoinNormalGetByIDReqPkt extends Data {
     public $id = 0;
}