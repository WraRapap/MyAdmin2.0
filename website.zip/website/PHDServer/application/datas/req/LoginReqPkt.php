<?php

class LoginReqPkt extends Data{
    public $acc;
    public $pwd;
}