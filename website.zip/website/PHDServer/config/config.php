<?php

// 数据库配置
define('DB_NAME', 'phdance');
define('DB_USER', 'puhueid');
define('DB_PASSWORD', '!qaz2wsx3edCLgsd230811');
define('DB_HOST', '127.0.0.1');

define('ST_PREFIX', 'ST');
define('AT_PREFIX', 'AT');


define('UPLOAD_FOLDER', '../activityupload/');