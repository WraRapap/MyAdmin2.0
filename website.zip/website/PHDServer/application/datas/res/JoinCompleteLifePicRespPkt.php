<?php

class JoinCompleteLifePicRespPkt {
    
}