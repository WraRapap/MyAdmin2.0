<?php

class ActivityQueryRespPkt {
    public $MonthlyData = null;            //帳號資料
}