<?php

class ActivityDelRespPkt {
}