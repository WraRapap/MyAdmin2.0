<?php

class JoinCompleteGetReqPkt extends Data {
    public $id = 0;
}