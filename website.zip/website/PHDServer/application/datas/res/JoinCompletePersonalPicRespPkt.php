<?php

class JoinCompletePersonalPicRespPkt {
    
}