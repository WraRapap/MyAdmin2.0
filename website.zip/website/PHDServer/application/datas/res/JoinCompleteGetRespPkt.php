<?php

class JoinCompleteGetRespPkt {
    public $completeData;            //徵選資料
}