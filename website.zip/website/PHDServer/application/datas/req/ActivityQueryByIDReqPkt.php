<?php

class ActivityQueryByIDReqPkt extends Data {
    public $id = 0;
}