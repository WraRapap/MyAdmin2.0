<?php

class JoinNormalGetByIDRespPkt {
    public $normalData;
}