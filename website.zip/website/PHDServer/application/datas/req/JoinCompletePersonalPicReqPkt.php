<?php

class JoinCompletePersonalPicReqPkt extends Data {
    public $memberID = 0;
}