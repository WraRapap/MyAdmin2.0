<?php

class JoinNormalReqPkt extends Data {
    public $name = "";
    public $phone = "";
    public $lesson = 0;
    public $email = "";
    public $message = "";
}