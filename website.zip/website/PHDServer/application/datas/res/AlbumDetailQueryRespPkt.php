<?php

class AlbumDetailQueryRespPkt {
    public $albumPicList = null;            //帳號資料
}