<?php

class JoinNormalRespPkt {
}