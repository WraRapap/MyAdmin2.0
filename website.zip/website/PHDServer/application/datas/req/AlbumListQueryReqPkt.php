<?php

class AlbumListQueryReqPkt extends Data {
    public $id;
}