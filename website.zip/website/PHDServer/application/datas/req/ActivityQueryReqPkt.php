<?php

class ActivityQueryReqPkt extends Data {
    public $id = 0;
    public $submenuID = 0;
}