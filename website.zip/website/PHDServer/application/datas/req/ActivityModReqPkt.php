<?php

class ActivityModReqPkt extends Data {
    public $id = 0;
    public $updateData;
}