var ResultMsg= 
{
	LoginReply : 
	{
		Failed : -1,
		Success : 0,
	},

	RegisterReply : 
	{
		AccRepeat : -2,
		Failed : -1,
		Success : 0,
	},
}