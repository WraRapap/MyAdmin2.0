<?php

class JoinNormalGetRespPkt {
    public $normalData;
}