<?php
$ActionType['0']='getAlbumList';          //取得所有相簿清單
$ActionType['1']='getAlbumDetail';        //取得相簿內容(需丟album_id)
$ActionType['2']='joinComplete';          //報名
$ActionType['3']="joinCompletePersonalPic"; //個人照片
$ActionType['4']="joinCompleteLifePic"; //個人照片
$ActionType['5']="joinNormal"; //一般報名
$ActionType['6']="login"; //登入
$ActionType['7']="joinCompleteGet"; //取徵選資料
$ActionType['8']="joinNormalGet"; //取課程報名資料
$ActionType['100']="joinNormalGetByID";

$ActionType['750']='queryActivity';      //取得所有後台使用者
$ActionType['751']='addActivity';        //新增後台使用者
$ActionType['752']='modActivity';      //修改後台使用者
$ActionType['753']='delActivity';        //刪除後台使用者
$ActionType['754']='queryActivityByID';        //刪除後台使用者
$ActionType['755']='addActivityImg';        //新增後台使用者
$ActionType['756']='queryActivityPic';      //取得所有後台使用者
