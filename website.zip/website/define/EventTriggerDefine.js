var EvDef = 
{
	AccChange : "Event_AccountChange",
	LanChange : "Event_LanguageChange",
}