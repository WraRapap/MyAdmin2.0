<?php

class ActivityImgAddRespPkt {
}