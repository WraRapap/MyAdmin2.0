<?php

class RespInfoPkt
{
    public $ret;
    public $data;
}