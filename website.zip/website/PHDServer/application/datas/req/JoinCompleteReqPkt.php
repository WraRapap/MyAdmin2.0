<?php

class JoinCompleteReqPkt extends Data {
    public $name = "";
    public $sex = 0;
    public $borthYear = 0;
    public $borthMonth = 0;
    public $borthDay = 0;
    public $identify = "";
    public $phone = "";
    public $address = "";
    public $email = "";
    public $company = "";
    public $school = "";
    public $research = "";
    public $danceYear = "";
    public $graudeYear = "";
    public $picNum = 0;
    public $showhistory = "";
}