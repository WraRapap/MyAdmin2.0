<?php

class ActivityAddRespPkt {
    public $id;
}