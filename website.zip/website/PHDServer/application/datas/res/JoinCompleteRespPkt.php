<?php

class JoinCompleteRespPkt {
    public $memberID = 0;            //帳號資料
}