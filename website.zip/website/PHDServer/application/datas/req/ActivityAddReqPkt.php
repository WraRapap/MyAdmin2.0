<?php

class ActivityAddReqPkt extends Data {
    public $name;
    public $descript;
    public $cover_id;
}