<?php

class AlbumListQueryRespPkt {
    public $albumList = null;            //帳號資料
}